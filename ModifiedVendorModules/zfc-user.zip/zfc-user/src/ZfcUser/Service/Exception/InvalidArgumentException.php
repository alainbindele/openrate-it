<?php

namespace ZfcUser\Service\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
